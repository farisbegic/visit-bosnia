create
    definer = root@localhost function GetObjectName(p_id int) returns varchar(255)
BEGIN
    declare ret varchar(255);
    select name into ret FROM object where oid = p_id;
    return ret;
END;

