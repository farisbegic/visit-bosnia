create definer = root@localhost view top_10_places as
select `o`.`oid`           AS `oid`,
       `o`.`name`          AS `object`,
       `o`.`street`        AS `street`,
       `c`.`name`          AS `city`,
       `o`.`averagerating` AS `averagerating`
from (`visitbosnia`.`object` `o`
         join `visitbosnia`.`city` `c`)
where `o`.`city` = `c`.`cid`
  and `o`.`active` = 1
order by `o`.`averagerating` desc
limit 0,6;

