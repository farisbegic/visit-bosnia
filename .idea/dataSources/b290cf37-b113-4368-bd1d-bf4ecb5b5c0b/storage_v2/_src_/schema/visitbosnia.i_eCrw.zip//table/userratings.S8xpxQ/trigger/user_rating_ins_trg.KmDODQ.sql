create definer = root@localhost trigger user_rating_ins_trg
    after insert
    on userratings
    for each row
BEGIN
    UPDATE object SET averagerating = (SELECT AVG(rating) FROM userratings WHERE oid = object);
END;

