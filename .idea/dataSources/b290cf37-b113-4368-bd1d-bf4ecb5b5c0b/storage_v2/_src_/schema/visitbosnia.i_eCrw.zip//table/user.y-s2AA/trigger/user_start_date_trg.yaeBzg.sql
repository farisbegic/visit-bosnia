create definer = root@localhost trigger user_start_date_trg
    before insert
    on user
    for each row
BEGIN
    set NEW.startdate = SYSDATE();
END;

