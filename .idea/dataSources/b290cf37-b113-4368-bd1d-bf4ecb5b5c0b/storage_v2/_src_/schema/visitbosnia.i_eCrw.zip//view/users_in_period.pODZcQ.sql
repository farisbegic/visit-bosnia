create definer = root@localhost view users_in_period as
select `visitbosnia`.`user`.`uid`                                AS `uid`,
       `visitbosnia`.`user`.`name`                               AS `name`,
       `visitbosnia`.`user`.`surname`                            AS `surname`,
       date_format(`visitbosnia`.`user`.`startdate`, '%d.%m.%Y') AS `start_date`,
       `visitbosnia`.`user`.`username`                           AS `username`,
       `visitbosnia`.`user`.`email`                              AS `email`
from `visitbosnia`.`user`
where (NULL is null or cast(`visitbosnia`.`user`.`startdate` as date) >= NULL)
  and (NULL is null or cast(`visitbosnia`.`user`.`startdate` as date) <= NULL)
  and `visitbosnia`.`user`.`active` = 1;

