create
    definer = root@localhost procedure user_ratings(IN p_oid int)
BEGIN
    UPDATE object SET averagerating = (SELECT AVG(rating) FROM userratings WHERE oid = p_oid) WHERE oid = p_oid;
END;

