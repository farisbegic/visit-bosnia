create definer = root@localhost view active_users as
select `visitbosnia`.`user`.`uid`       AS `uid`,
       `visitbosnia`.`user`.`name`      AS `name`,
       `visitbosnia`.`user`.`surname`   AS `surname`,
       `visitbosnia`.`user`.`username`  AS `username`,
       `visitbosnia`.`user`.`email`     AS `email`,
       `visitbosnia`.`user`.`startdate` AS `startdate`
from `visitbosnia`.`user`
where `visitbosnia`.`user`.`active` = 1;

