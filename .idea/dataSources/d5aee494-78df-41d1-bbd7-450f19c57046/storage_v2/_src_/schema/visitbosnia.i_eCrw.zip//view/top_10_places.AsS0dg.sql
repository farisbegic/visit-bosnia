create definer = root@localhost view top_10_places as
select `o`.`oid`           AS `oid`,
       `o`.`name`          AS `name`,
       `o`.`street`        AS `street`,
       `o`.`start_day`     AS `start_day`,
       `o`.`close_day`     AS `close_day`,
       `o`.`opening_hours` AS `opening_hours`,
       `o`.`closing_hours` AS `closing_hours`,
       `o`.`phone`         AS `phone`,
       `o`.`webpage`       AS `webpage`,
       `o`.`image`         AS `image`,
       `o`.`active`        AS `active`
from (`visitbosnia`.`object` `o`
         join `visitbosnia`.`city` `c`)
where `o`.`city` = `c`.`cid`
  and `o`.`active` = 1
order by `o`.`averagerating` desc
limit 0,6;

