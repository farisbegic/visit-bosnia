create definer = root@localhost view most_active_users as
select `visitbosnia`.`userratings`.`user`                AS `user`,
       `GetUserName`(`visitbosnia`.`userratings`.`user`) AS `GetUserName(user)`,
       count(0)                                          AS `favno`
from (`visitbosnia`.`userratings`
         join `visitbosnia`.`user`)
where `visitbosnia`.`user`.`uid` = `visitbosnia`.`userratings`.`user`
  and `visitbosnia`.`user`.`active` = 1
group by `GetUserName`(`visitbosnia`.`userratings`.`user`)
order by 2 desc;

