create
    definer = root@localhost procedure ClearAllUserData()
BEGIN
    DELETE FROM userratings where 1;
    DELETE FROM userfavorites where 1;
    DELETE FROM user where 1;
END;

