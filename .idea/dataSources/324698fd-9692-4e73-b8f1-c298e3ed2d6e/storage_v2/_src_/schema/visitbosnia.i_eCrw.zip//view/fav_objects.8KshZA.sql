create definer = root@localhost view fav_objects as
select `uf`.`object` AS `objectid`, `o`.`name` AS `object`, count(`uf`.`object`) AS `favnum`
from ((`visitbosnia`.`object` `o` join `visitbosnia`.`user` `u`)
         join `visitbosnia`.`userfavorites` `uf`)
where `o`.`oid` = `uf`.`object`
  and `u`.`uid` = `uf`.`user`
  and (NULL is null or cast(`u`.`startdate` as date) >= NULL)
  and (NULL is null or cast(`u`.`startdate` as date) <= NULL)
  and `o`.`active` = 1
group by `uf`.`object`;

