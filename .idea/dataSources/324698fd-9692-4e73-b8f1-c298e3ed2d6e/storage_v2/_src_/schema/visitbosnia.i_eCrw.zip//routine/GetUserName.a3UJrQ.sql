create
    definer = root@localhost function GetUserName(p_id int) returns varchar(255)
BEGIN
    declare ret varchar(255);
    select concat(name, ' ', surname) into ret FROM user where uid = p_id;
    return ret;
END;

