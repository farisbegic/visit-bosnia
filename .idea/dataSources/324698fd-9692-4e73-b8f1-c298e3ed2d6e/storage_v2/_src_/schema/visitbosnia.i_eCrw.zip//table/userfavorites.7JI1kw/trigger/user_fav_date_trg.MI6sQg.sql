create definer = root@localhost trigger user_fav_date_trg
    before insert
    on userfavorites
    for each row
BEGIN
    set NEW.date = SYSDATE();
END;

