create definer = root@localhost trigger date_check
    before insert
    on user
    for each row
BEGIN
    DECLARE msg varchar(255);
    IF NEW.dob > CURDATE()  THEN
        SET msg = 'INVALID DATE, Date from future';
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = msg;
    END IF;
END;

